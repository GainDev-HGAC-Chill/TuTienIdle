# Fix Nhật Ký Đạo Hành frontend

Copy đè 2 file:

- `frontend/script.js`
- `frontend/actionLogClient.js`

Sau đó chạy:

```bat
node --check frontend\script.js
node --check frontendctionLogClient.js
npm start
```

Vào trình duyệt nhấn `Ctrl + F5`.

Nội dung sửa chính:

- `renderAll()` trong `script.js` giờ gọi `window.renderActivityLog()`.
- `actionLogClient.js` đọc `window.playerData.activityLog` trước.
- Nếu `playerData.activityLog` chưa có, nó tự gọi API `/api/player/:username/action-log?limit=80`.
- Tự dọn các panel log cũ bị trùng.
