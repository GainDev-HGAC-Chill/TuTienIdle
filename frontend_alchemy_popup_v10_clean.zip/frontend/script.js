const API_BASE = '';
const $ = id => document.getElementById(id);
const fmt = value => Number(value || 0).toLocaleString('vi-VN', { maximumFractionDigits: 0 });
const pct = (cur, max) => max > 0 && Number.isFinite(Number(max)) ? Math.max(0, Math.min(100, (Number(cur || 0) / Number(max)) * 100)) : 0;

let username = localStorage.getItem('tuTienUsername') || '';
let playerData = null;
let metaData = null;
let currentTab = localStorage.getItem('tuTienActiveTab') || 'overview';
let refreshTimer = null;
const collapsedMapGroups = new Set();

const pageInfo = {
  overview: ['Tổng Quan', 'Theo dõi cảnh giới, chiến lực và tài nguyên.'],
  cultivation: ['Tu Luyện', 'Điều phối tu luyện, luyện thể và luyện hồn.'],
  combat: ['Combat', 'Tự động đánh quái theo map đã mở.'],
  skills: ['Công Pháp', 'Công pháp và vũ kỹ cơ bản của ba hệ.'],
  alchemy: ['Đan Dược', 'Luyện đan, dùng đan và quản lý thọ nguyên.'],
  cave: ['Động Phủ', 'Linh khí, phòng luyện đan và dược viên.'],
  inventory: ['Túi Đồ', 'Vật phẩm, đan dược và nguyên liệu.'],
};

function escapeHtml(text) {
  return String(text ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;' }[c]));
}

function setText(id, value) {
  const el = $(id);
  if (el) el.textContent = value;
}

function setWidth(id, value) {
  const el = $(id);
  if (el) el.style.width = `${Math.max(0, Math.min(100, Number(value || 0)))}%`;
}

function systemName(id) {
  return { cultivation: 'Tu Luyện', body: 'Luyện Thể', soul: 'Luyện Hồn', main: 'Tu Luyện' }[id] || id || '-';
}

async function api(path, options = {}) {
  const res = await fetch(`${API_BASE}${path}`, {
    headers: { 'Content-Type': 'application/json' },
    ...options,
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok || data.success === false) throw new Error(data.error || data.reason || 'Lỗi máy chủ');
  return data;
}

function showApp() {
  $('login-screen')?.classList.add('hidden');
  $('app')?.classList.remove('hidden');
}

function showLogin() {
  $('app')?.classList.add('hidden');
  $('login-screen')?.classList.remove('hidden');
}

async function loadMeta() {
  try { metaData = await api('/api/meta'); } catch (err) { console.warn(err.message); }
}

async function loadPlayer() {
  if (!username) return;
  try {
    const data = await api(`/api/player/${encodeURIComponent(username)}`);
    playerData = data.player;
    setText('connection-status', 'Đã kết nối');
    renderAll();
  } catch (err) {
    setText('connection-status', err.message);
  }
}

async function postPlayer(body) {
  const data = await api(`/api/player/${encodeURIComponent(username)}`, { method: 'POST', body: JSON.stringify(body) });
  playerData = data.player;
  renderAll();
}

function bindEvents() {
  $('login-btn')?.addEventListener('click', login);
  $('username-input')?.addEventListener('keydown', e => { if (e.key === 'Enter') login(); });
  $('logout-btn')?.addEventListener('click', logout);
  $('refresh-btn')?.addEventListener('click', loadPlayer);
  $('toggle-auto-btn')?.addEventListener('click', toggleAutoFight);
  document.querySelectorAll('.nav-btn').forEach(btn => btn.addEventListener('click', () => setTab(btn.dataset.tab)));
}

async function login() {
  username = $('username-input')?.value.trim() || 'dao_huu';
  localStorage.setItem('tuTienUsername', username);
  showApp();
  await loadMeta();
  await loadPlayer();
  setTab(currentTab, true);
  startTimer();
}

function logout() {
  localStorage.removeItem('tuTienUsername');
  username = '';
  playerData = null;
  if (refreshTimer) clearInterval(refreshTimer);
  showLogin();
}

function startTimer() {
  if (refreshTimer) clearInterval(refreshTimer);
  refreshTimer = setInterval(loadPlayer, 3000);
}

function setTab(tab, shouldSync = true) {
  currentTab = tab;
  localStorage.setItem('tuTienActiveTab', tab);
  document.querySelectorAll('.nav-btn').forEach(btn => btn.classList.toggle('active', btn.dataset.tab === tab));
  document.querySelectorAll('.tab-page').forEach(page => page.classList.toggle('active', page.id === `tab-${tab}`));
  const info = pageInfo[tab] || pageInfo.overview;
  setText('page-title', info[0]);
  setText('page-subtitle', info[1]);

  if (playerData) {
    playerData.activeTab = tab;
    renderActivityHint();
  }
  if (shouldSync && username) syncActiveTab(tab);
}

async function syncActiveTab(tab) {
  try {
    const data = await api(`/api/player/${encodeURIComponent(username)}`, {
      method: 'POST',
      body: JSON.stringify({ activeTab: tab })
    });
    playerData = data.player;
    renderAll();
  } catch (err) {
    console.warn('Không thể đổi mục hoạt động:', err.message);
  }
}

function renderActivityHint() {
  const active = playerData?.activeTab || currentTab || 'overview';
  document.querySelectorAll('[data-activity-mode]').forEach(el => {
    const mode = el.dataset.activityMode;
    el.classList.toggle('activity-active', mode === active);
    el.classList.toggle('activity-paused', mode !== active);
  });
}


function renderAll() {
  if (!playerData) return;
  window.playerData = playerData;
  renderHeader();
  renderEncounter();
  renderOverview();

  window.playerData = playerData;
  if (typeof window.renderActivityLog === 'function') window.renderActivityLog();
  renderCultivation();
  renderCombat();
  renderSkills();
  renderAlchemy();
  renderCave();
  renderInventory();
  renderActivityHint();
}

function renderHeader() {
  setText('profile-name', playerData.username || '-');
  setText('profile-realm', playerData.cultivation?.realmName || '-');
  setText('toggle-auto-btn', playerData.autoFight ? 'Tạm dừng tự đánh' : 'Bật tự đánh');
}

function renderEncounter() {
  const box = $('encounter-popup');
  const encounter = playerData.encounter?.active || playerData.pendingEncounter || null;
  if (!box) return;
  if (!encounter) {
    box.classList.add('hidden');
    box.innerHTML = '';
    return;
  }
  const choices = encounter.choices || [];
  box.classList.remove('hidden');
  box.innerHTML = `
    <div class="encounter-card">
      <h2>${escapeHtml(encounter.name || 'Kỳ Ngộ Thiên Cơ')}</h2>
      <p>${escapeHtml(encounter.description || 'Một cơ duyên bất ngờ xuất hiện.')}</p>
      <div class="button-row">
        ${choices.map(choice => `<button type="button" data-encounter-choice="${escapeHtml(choice.id)}">${escapeHtml(choice.label || choice.name || 'Lựa chọn')}</button>`).join('')}
        <button type="button" class="danger" data-encounter-decline>Không thực hiện</button>
      </div>
      <small>Từ chối kỳ ngộ sẽ bị thiên phạt 5% tổng thuộc tính trong 60 phút.</small>
    </div>`;
  box.querySelectorAll('[data-encounter-choice]').forEach(btn => btn.addEventListener('click', () => chooseEncounter(btn.dataset.encounterChoice)));
  box.querySelector('[data-encounter-decline]')?.addEventListener('click', declineEncounter);
}

async function chooseEncounter(choiceId) {
  try {
    const data = await api(`/api/player/${encodeURIComponent(username)}/encounter/choose`, { method: 'POST', body: JSON.stringify({ choiceId }) });
    playerData = data.player;
    renderAll();
  } catch (err) { alert(err.message); }
}

async function declineEncounter() {
  try {
    const data = await api(`/api/player/${encodeURIComponent(username)}/encounter/decline`, { method: 'POST', body: JSON.stringify({}) });
    playerData = data.player;
    renderAll();
  } catch (err) { alert(err.message); }
}

function renderOverview() {
  const c = playerData.cultivation || {};
  const combat = playerData.combat || {};
  const root = playerData.spiritRootDisplay || {};
  setText('world-name', c.info?.worldName || c.info?.world || c.worldName || '-');
  setText('realm-name', c.realmName || '-');
  setText('tuvi-text', `${fmt(c.exp ?? c.tuVi)} / ${fmt(c.maxExp ?? c.maxTuVi)}`);
  setText('hp-text', `${fmt(combat.hp)} / ${fmt(combat.maxHp)}`);
  setText('atk-text', fmt(combat.atk));
  setText('def-text', fmt(combat.def));
  setText('spirit-root-name', root.name || 'Chưa ngộ linh căn');
  setText('spirit-root-desc', root.description || 'Tính năng linh căn sẽ mở ở bước sau.');
  setText('body-rank', playerData.bodyCultivation?.info?.name || playerData.bodyCultivation?.name || '-');
  setText('soul-rank', playerData.soulCultivation?.info?.name || playerData.soulCultivation?.name || '-');

  const currencies = playerData.currencies || {};
  $('currency-list').innerHTML = Object.entries(currencies)
    .filter(([, amount]) => Number(amount) > 0)
    .map(([id, amount]) => smallCard(currencyName(id), fmt(amount), 'Tiền tệ'))
    .join('') || '<p class="empty">Chưa có tài nguyên.</p>';
}

function progressData(type) {
  if (type === 'main') {
    const c = playerData.cultivation || {};
    return { type, title: c.realmName || '-', cur: c.exp ?? c.tuVi ?? 0, max: c.maxExp ?? c.maxTuVi ?? 100, sub: c.info?.worldName || c.worldName || '-' };
  }
  if (type === 'body') {
    const b = playerData.bodyCultivation || {};
    return { type, title: b.info?.name || b.name || 'Luyện Thể', cur: b.exp || 0, max: b.maxExp || 100, sub: 'Khí huyết rèn thân' };
  }
  const s = playerData.soulCultivation || {};
  return { type, title: s.info?.name || s.name || 'Luyện Hồn', cur: s.exp || 0, max: s.maxExp || 100, sub: 'Thần thức dưỡng hồn' };
}

function formatActivityTime(at) {

 const time = Number(at || 0);

 if (!time) return '';

 return new Date(time).toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit', second: '2-digit' });

}

function renderActivityLog() {

 const box = $('activity-log-list');

 if (!box) return;

 const logs = Array.isArray(playerData.activityLog) ? playerData.activityLog : [];

 if (!logs.length) {
  box.innerHTML = '<p class="empty">Chưa có đạo hành nào được ghi nhận.</p>';
  return;
 }

 box.innerHTML = logs.map(item => {
  const category = escapeHtml(item.categoryLabel || item.category || 'Thiên Cơ');
  const text = escapeHtml(item.text || 'Hoạt động không rõ');
  const detail = item.detail ? '<p>' + escapeHtml(item.detail) + '</p>' : '';
  const time = escapeHtml(formatActivityTime(item.at));
  return '<div class="activity-log-item activity-' + escapeHtml(item.category || 'system') + '"><div><b>' + category + '</b><span>' + time + '</span></div><strong>' + text + '</strong>' + detail + '</div>';
 }).join('');

}


// ===============================
// Nhật Ký Đạo Hành - Tổng Quan
// ===============================
function formatActivityTime(at) {
 const time = Number(at || 0);
 if (!time) return '';
 return new Date(time).toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
}
function ensureActivityPanel() {
 let box = $('activity-log-list');
 if (box) return box;
 const overview = $('tab-overview');
 if (!overview) return null;
 const panel = document.createElement('div');
 panel.className = 'panel wide activity-panel';
 panel.innerHTML = '<div class="panel-head"><h3>Nhật Ký Đạo Hành</h3><span>Không gồm combat</span></div><div id="activity-log-list" class="activity-log-list"></div>';
 overview.appendChild(panel);
 return $('activity-log-list');
}
function renderActivityLog() {
 const box = ensureActivityPanel();
 if (!box) return;
 const logs = Array.isArray(playerData?.activityLog) ? playerData.activityLog : [];
 if (!logs.length) {
  box.innerHTML = '<p class="empty">Chưa có đạo hành nào được ghi nhận.</p>';
  return;
 }
 box.innerHTML = logs.map(item => {
  const category = escapeHtml(item.categoryLabel || item.category || 'Thiên Cơ');
  const text = escapeHtml(item.text || 'Hoạt động không rõ');
  const detail = item.detail ? '<p>' + escapeHtml(item.detail) + '</p>' : '';
  const time = escapeHtml(formatActivityTime(item.at));
  return '<div class="activity-log-item activity-' + escapeHtml(item.category || 'system') + '"><div><b>' + category + '</b><span>' + time + '</span></div><strong>' + text + '</strong>' + detail + '</div>';
 }).join('');
}
function renderCultivation() {
  const c = playerData.cultivation || {};
  const tuviGain = playerData.pillEffects?.tuViGainPerSecond || playerData.tuViGainPerSecond || 1;
  setText('cultivation-title', `${c.realmName || '-'} · ${fmt(c.exp ?? c.tuVi)} / ${fmt(c.maxExp ?? c.maxTuVi)}`);
  setText('cult-world', c.info?.worldName || c.worldName || '-');
  setText('cult-type', c.info?.name || '-');
  setText('tuvi-rate', `${fmt(tuviGain)}/s`);

  const state = playerData.cultivationFocusState || { selected: ['main'], limit: 1, options: ['main', 'body', 'soul'] };
  const selected = Array.isArray(state.selected) ? state.selected : ['main'];
  const options = Array.isArray(state.options) ? state.options : ['main', 'body', 'soul'];
  setText('focus-limit', `Đang tu ${selected.length}/${state.limit || 1} mạch`);
  const activeMode = playerData.activeTab || currentTab;
  setText('focus-note', activeMode === 'cultivation'
    ? ((state.limit || 1) === 1 ? 'Đang vận chuyển tu luyện. Rời tab này thì tu luyện tạm dừng.' : `Có thể đồng tu ${state.limit} mạch. Rời tab này thì tu luyện tạm dừng.`)
    : 'Tu luyện đang tạm dừng vì đang ở mục khác. Chọn tab Tu Luyện để vận chuyển.');

  $('cultivation-progress-panels').innerHTML = options.map(type => {
    const d = progressData(type);
    const w = pct(d.cur, d.max);
    const active = selected.includes(type);
    return `
      <button type="button" class="progress-panel ${active ? 'active' : ''}" data-focus="${type}">
        <div class="progress-head"><span>${systemName(type)}</span><b>${active ? 'Đang tu' : 'Tạm dừng'}</b></div>
        <h4>${escapeHtml(d.title)}</h4>
        <p>${escapeHtml(d.sub)}</p>
        <div class="bar"><i style="width:${w}%"></i></div>
        <div class="progress-foot"><b>${fmt(d.cur)} / ${fmt(d.max)}</b><span>${Math.round(w)}%</span></div>
      </button>`;
  }).join('');

  $('focus-buttons').innerHTML = options.map(type => {
    const active = selected.includes(type);
    return `<button type="button" class="${active ? 'success' : ''}" data-focus="${type}">${active ? 'Đang tu' : 'Chọn'}: ${systemName(type)}</button>`;
  }).join('');
  document.querySelectorAll('[data-focus]').forEach(btn => btn.addEventListener('click', () => toggleFocus(btn.dataset.focus)));

  const buffs = playerData.activePillBuffs || [];
  $('pill-buffs').innerHTML = buffs.length
    ? buffs.map(buff => smallCard(buff.name || buff.id, buff.remainingMs ? `Còn ${Math.ceil(buff.remainingMs / 1000)} giây` : 'Đang hiệu lực')).join('')
    : '<p class="empty">Chưa có buff đan.</p>';
}

async function toggleFocus(type) {
  try {
    const data = await api(`/api/player/${encodeURIComponent(username)}/cultivation/focus`, { method: 'POST', body: JSON.stringify({ type }) });
    playerData = data.player;
    renderAll();
  } catch (err) { alert(err.message); }
}

async function toggleAutoFight() {
  try { await postPlayer({ autoFight: !playerData.autoFight }); } catch (err) { alert(err.message); }
}

function mapGroupKey(map) {
  return `${map.worldName || map.world || '-'}|${map.realmName || map.realm || 'Cảnh giới'}`;
}

function renderMapGroups(maps) {
  if (!maps.length) return '<p class="empty">Chưa mở map.</p>';
  const groups = new Map();
  maps.forEach(map => {
    const key = mapGroupKey(map);
    if (!groups.has(key)) groups.set(key, []);
    groups.get(key).push(map);
  });
  return [...groups.entries()].map(([key, items]) => {
    const [world, realm] = key.split('|');
    const collapsed = collapsedMapGroups.has(key);
    const body = collapsed ? '' : `<div class="map-group-body">${items.map(item => `
      <button type="button" class="map-card ${playerData.currentZone === item.id ? 'active' : ''}" data-map="${escapeHtml(item.id)}">
        <b>${escapeHtml(item.name)}</b>
        <span>${escapeHtml(item.worldName || world)} · ${escapeHtml(item.realmName || realm)}</span>
        ${item.description ? `<p>${escapeHtml(item.description)}</p>` : ''}
      </button>`).join('')}</div>`;
    return `<div class="map-group">
      <button type="button" class="map-group-head" data-map-group="${escapeHtml(key)}">
        <b>${escapeHtml(world)} · ${escapeHtml(realm)}</b><span>${collapsed ? 'Mở' : 'Thu gọn'} (${items.length})</span>
      </button>${body}</div>`;
  }).join('');
}

function renderCombat() {
  const map = playerData.currentMap || {};
  const state = playerData.combatState || {};
  const combat = playerData.combat || {};
  const monster = state.currentMonster || {};
  setText('combat-zone', map.name || playerData.zoneName || '-');
  setText('monster-name', monster.name || 'Không rõ');
  setText('combat-status', (playerData.activeTab || currentTab) === 'combat' ? (state.status || (playerData.autoFight ? 'Đang tự đánh' : 'Tự đánh đang tắt')) : 'Combat tạm dừng vì đang ở mục khác.');
  setText('combat-player-hp', `${fmt(combat.hp)} / ${fmt(combat.maxHp)}`);
  setText('combat-monster-hp', `${fmt(state.monsterHp)} / ${fmt(state.monsterMaxHp)}`);
  setText('fight-progress-text', `${Math.round(pct(state.fightProgress || 0, state.fightDuration || 3000))}%`);
  setWidth('fight-progress-bar', pct(state.fightProgress || 0, state.fightDuration || 3000));
  setWidth('player-hp-bar', pct(combat.hp, combat.maxHp));
  setWidth('monster-hp-bar', pct(state.monsterHp, state.monsterMaxHp));
  setText('auto-fight-status', playerData.autoFight ? 'Đang bật' : 'Đang tắt');
  setText('kill-count', fmt(playerData.stats?.totalKills || 0));
  setText('death-penalty', `${fmt(state.deathPenaltyPercent || playerData.temporaryPenaltyPercent || 0)}%`);

  $('map-list').innerHTML = renderMapGroups(playerData.unlockedMaps || []);
  document.querySelectorAll('[data-map-group]').forEach(btn => btn.addEventListener('click', () => {
    const key = btn.dataset.mapGroup;
    if (collapsedMapGroups.has(key)) collapsedMapGroups.delete(key); else collapsedMapGroups.add(key);
    renderCombat();
  }));
  document.querySelectorAll('[data-map]').forEach(btn => btn.addEventListener('click', () => changeMap(btn.dataset.map)));

  const logs = state.logs || [];
  $('combat-logs').innerHTML = logs.length
    ? logs.slice(-40).reverse().map(line => `<p>${escapeHtml(line)}</p>`).join('')
    : '<p class="empty">Chưa có nhật ký.</p>';
}

async function changeMap(mapId) {
  try {
    const data = await api(`/api/player/${encodeURIComponent(username)}/zone`, { method: 'POST', body: JSON.stringify({ mapId }) });
    playerData = data.player;
    renderAll();
  } catch (err) { alert(err.message); }
}

function smallCard(title, body = '', meta = '') {
  return `<div class="mini-card"><div><b>${escapeHtml(title)}</b>${body ? `<p>${escapeHtml(body)}</p>` : ''}</div>${meta ? `<span>${escapeHtml(meta)}</span>` : ''}</div>`;
}

function effectChips(effects = {}) {
  const entries = Object.entries(effects || {});
  if (!entries.length) return '<span class="chip">Chưa có chỉ số</span>';
  return entries.map(([k, v]) => {
    let val = v;
    if (typeof v === 'number') val = Math.abs(v) < 1 ? `${Math.round(v * 100)}%` : v;
    return `<span class="chip"><b>${escapeHtml(k)}</b> ${escapeHtml(val)}</span>`;
  }).join('');
}

function renderSkills() {
  const techState = playerData.techniques || { equipped: {}, learned: [] };
  const martialState = playerData.martialSkills || { equipped: {}, learned: [] };
  const techniques = Array.isArray(techState.learned) ? techState.learned : Object.values(techState.learned || {});
  const martial = Array.isArray(martialState.learned) ? martialState.learned : Object.values(martialState.learned || {});

  $('technique-list').innerHTML = techniques.length ? techniques.map(item => {
    const slot = item.system || item.type || 'cultivation';
    const equipped = techState.equipped?.[slot] === item.id;
    return practiceCard(item, equipped, 'technique');
  }).join('') : '<p class="empty">Chưa học công pháp.</p>';

  $('martial-list').innerHTML = martial.length ? martial.map(item => {
    const equipped = martialState.equipped?.active === item.id;
    return practiceCard(item, equipped, 'martial-skill');
  }).join('') : '<p class="empty">Chưa học vũ kỹ.</p>';

  document.querySelectorAll('[data-equip-kind]').forEach(btn => btn.addEventListener('click', () => equipPracticeItem(btn.dataset.equipKind, btn.dataset.equipId)));
  $('skill-list').innerHTML = '<p class="empty">Skill theo linh căn sẽ mở sau khi hoàn thiện linh căn.</p>';
}

function practiceCard(item, equipped, kind) {
  const system = item.system || item.type || 'cultivation';
  return `<div class="practice-card ${equipped ? 'equipped' : ''}">
    <div class="practice-top"><h4>${escapeHtml(item.name || item.id)}</h4><span>Bậc ${fmt(item.rank || 1)}</span></div>
    <b class="practice-system">${systemName(system)}</b>
    <p>${escapeHtml(item.description || '')}</p>
    <div class="chip-row">${effectChips(item.effects)}</div>
    <div class="practice-bottom"><strong>${equipped ? (kind === 'technique' ? 'Đang vận chuyển' : 'Đang xuất chiến') : 'Chưa trang bị'}</strong>${equipped ? '<button type="button" disabled>Đã trang bị</button>' : `<button type="button" data-equip-kind="${kind}" data-equip-id="${escapeHtml(item.id)}">Trang bị</button>`}</div>
  </div>`;
}

async function equipPracticeItem(kind, id) {
  try {
    const data = await api(`/api/player/${encodeURIComponent(username)}/${kind}/equip`, { method: 'POST', body: JSON.stringify({ id }) });
    playerData = data.player;
    renderAll();
  } catch (err) { alert(err.message); }
}


// ===============================
// Đan Các Popup V10 - giao diện gọn, không render list dài trong thẻ cảnh giới
// ===============================
const ALCHEMY_REALMS_V10 = [
  { level: 1, name: 'Luyện Khí' },
  { level: 2, name: 'Trúc Cơ' },
  { level: 3, name: 'Kim Đan' },
  { level: 4, name: 'Nguyên Anh' },
  { level: 5, name: 'Hóa Thần' },
  { level: 6, name: 'Luyện Hư' },
  { level: 7, name: 'Hợp Thể' },
  { level: 8, name: 'Đại Thừa' },
  { level: 9, name: 'Độ Kiếp' },
];

function alchemyMetaListV10(name) {
  return Array.isArray(metaData?.[name]) ? metaData[name] : [];
}

function alchemyAllItemsV10() {
  return []
    .concat(alchemyMetaListV10('materials'))
    .concat(alchemyMetaListV10('herbs'))
    .concat(alchemyMetaListV10('pills'))
    .concat(alchemyMetaListV10('lifespanPills'));
}

function alchemyFindItemV10(id) {
  return alchemyAllItemsV10().find(item => item && String(item.id) === String(id)) || null;
}

function alchemyItemNameV10(id) {
  return alchemyFindItemV10(id)?.name || currencyName(id) || id || '-';
}

function alchemyTimeTextV10(msOrSec) {
  const raw = Number(msOrSec || 0);
  const sec = raw > 1000 ? Math.ceil(raw / 1000) : Math.ceil(raw);
  if (sec <= 0) return 'Tức thời';
  if (sec < 60) return `${sec} giây`;
  const min = Math.floor(sec / 60);
  const rest = sec % 60;
  if (min < 60) return rest ? `${min} phút ${rest} giây` : `${min} phút`;
  const hour = Math.floor(min / 60);
  const remainMin = min % 60;
  return remainMin ? `${hour} giờ ${remainMin} phút` : `${hour} giờ`;
}

function alchemyPlayerLevelV10() {
  const state = playerData?.alchemy || playerData?.alchemyState || {};
  return Number(state.level || state.rank || playerData?.alchemyLevel || 1) || 1;
}

function alchemyRecipesV10() {
  const list = alchemyMetaListV10('recipes');
  return list.length ? list : (Array.isArray(playerData?.recipes) ? playerData.recipes : []);
}

function alchemyRecipeLevelV10(recipe) {
  return Number(recipe?.alchemyLevel || recipe?.requiredAlchemyLevel || recipe?.requiredRank || recipe?.rank || recipe?.realmLevel || recipe?.level || 1) || 1;
}

function alchemyRecipeMaterialsV10(recipe) {
  const list = recipe?.ingredients || recipe?.materials || recipe?.costItems || recipe?.requires || [];
  return Array.isArray(list) ? list : [];
}

function alchemyFindPillV10(id) {
  if (!id) return null;
  const cleanId = String(id).replace(/_(thuong|tot|cuc_pham|normal|good|perfect)$/i, '');
  return alchemyMetaListV10('pills').concat(alchemyMetaListV10('lifespanPills'))
    .find(pill => pill && (String(pill.id) === String(id) || String(pill.id) === cleanId)) || alchemyFindItemV10(cleanId) || alchemyFindItemV10(id);
}

function alchemyRecipePillV10(recipe) {
  return alchemyFindPillV10(recipe?.pillId || recipe?.resultPillId || recipe?.resultId || recipe?.outputId || recipe?.itemId);
}

function alchemyEffectTextV10(pillOrRecipe) {
  const data = pillOrRecipe || {};
  const labels = {
    cultivationSpeedBonus: 'Tốc độ tu luyện', auraBonus: 'Linh khí', tuViBonus: 'Tu vi', tuViGainPerSecond: 'Tu vi mỗi giây',
    breakthroughBonus: 'Tỷ lệ đột phá', breakthroughRateBonus: 'Tỷ lệ đột phá', hpBonus: 'Sinh mệnh', atkBonus: 'Công kích',
    defBonus: 'Phòng ngự', bodyExpBonus: 'Kinh nghiệm luyện thể', soulExpBonus: 'Kinh nghiệm luyện hồn', soulPowerBonus: 'Hồn lực',
    damageMultiplier: 'Sát thương', extraDamage: 'Sát thương thêm'
  };
  const out = [];
  if (data.description) out.push(data.description);
  if (data.effectText) out.push(data.effectText);
  if (data.addYears) out.push(`Tăng ${fmt(data.addYears)} năm thọ nguyên`);
  if (data.durationMs || data.durationSeconds) out.push(`Hiệu lực ${alchemyTimeTextV10(data.durationMs || data.durationSeconds)}`);
  if (data.maxUses) out.push(`Giới hạn dùng ${fmt(data.maxUses)} lần`);
  if (data.realmMinOrder) out.push(`Yêu cầu cảnh giới bậc ${fmt(data.realmMinOrder)} trở lên`);
  Object.entries(data.effects || data.effect || data.stats || {}).forEach(([key, value]) => {
    let shown = value;
    if (typeof value === 'number') shown = Math.abs(value) < 1 ? `${Math.round(value * 100)}%` : fmt(value);
    out.push(`${labels[key] || key}: ${shown}`);
  });
  return [...new Set(out.filter(Boolean))].join(' · ') || 'Công hiệu chưa được khai mở.';
}

function alchemySuccessTextV10(recipe) {
  const value = recipe?.successRate ?? recipe?.successChance ?? recipe?.baseSuccessRate ?? recipe?.rate ?? recipe?.chance;
  if (value === undefined || value === null || value === '') return 'Theo bậc Đan Sư hiện tại';
  const n = Number(value);
  if (!Number.isFinite(n)) return String(value);
  return n <= 1 ? `${Math.round(n * 100)}%` : `${Math.round(n)}%`;
}

function alchemyRequirementTextV10(recipe) {
  const level = alchemyRecipeLevelV10(recipe);
  const realm = ALCHEMY_REALMS_V10.find(item => item.level === level);
  return recipe?.alchemyRankName || recipe?.requiredRankName || recipe?.requiredAlchemyRank || `Đan sư cấp ${level}${realm ? ` · ${realm.name}` : ''}`;
}

function alchemyInventoryAmountV10(id) {
  const inv = Array.isArray(playerData?.inventory) ? playerData.inventory : [];
  const item = inv.find(it => String(it.id) === String(id));
  return Number(item?.amount || item?.count || 0);
}

function alchemyMaterialRowsV10(recipe) {
  const rows = alchemyRecipeMaterialsV10(recipe).map(mat => {
    const id = mat.id || mat.itemId || mat.materialId || mat.herbId || mat.currency;
    const need = Number(mat.amount || mat.count || mat.qty || 1);
    const have = alchemyInventoryAmountV10(id);
    return `<div class="alchemy-material-row ${have >= need ? 'enough' : 'missing'}"><span>${escapeHtml(alchemyItemNameV10(id))}</span><b>${fmt(have)} / ${fmt(need)}</b></div>`;
  });
  const cost = Number(recipe?.cost || recipe?.linhThachCost || recipe?.spiritStoneCost || 0);
  if (cost > 0) rows.push(`<div class="alchemy-material-row"><span>Sơ Linh Thạch</span><b>${fmt(cost)}</b></div>`);
  return rows.length ? rows.join('') : '<p class="empty">Không yêu cầu nguyên liệu.</p>';
}

function alchemyInventoryPillsV10() {
  const inv = Array.isArray(playerData?.inventory) ? playerData.inventory : [];
  const pillIds = new Set(alchemyMetaListV10('pills').concat(alchemyMetaListV10('lifespanPills')).map(item => String(item.id)));
  return inv.filter(item => {
    const id = String(item?.id || '').toLowerCase();
    const baseId = String(item?.basePillId || item?.pillId || '').toLowerCase();
    const type = String(item?.type || item?.category || '').toLowerCase();
    if (type.includes('seed') || type.includes('herb') || type.includes('material')) return false;
    if (id.includes('hat_giong') || id.includes('seed') || id.includes('thao') || id.includes('duoc_lieu')) return false;
    return Boolean(item?.basePillId || item?.pillId || pillIds.has(String(item?.id)) || type === 'pill' || type === 'dan_duoc' || id.endsWith('_dan') || id.includes('_dan_'));
  });
}

function ensureAlchemyPopupV10() {
  let popup = document.getElementById('alchemy-popup-v10');
  if (popup) return popup;
  popup = document.createElement('div');
  popup.id = 'alchemy-popup-v10';
  popup.className = 'alchemy-popup hidden';
  popup.innerHTML = '<div class="alchemy-popup-mask" data-alchemy-popup-close></div><section class="alchemy-popup-box"><button type="button" class="alchemy-popup-close" data-alchemy-popup-close>×</button><div id="alchemy-popup-content"></div></section>';
  document.body.appendChild(popup);
  popup.addEventListener('click', event => {
    if (event.target?.hasAttribute('data-alchemy-popup-close')) closeAlchemyPopupV10();
  });
  document.addEventListener('keydown', event => {
    if (event.key === 'Escape') closeAlchemyPopupV10();
  });
  return popup;
}

function openAlchemyPopupV10(content) {
  const popup = ensureAlchemyPopupV10();
  const body = document.getElementById('alchemy-popup-content');
  if (body) body.innerHTML = content;
  popup.classList.remove('hidden');
  document.body.classList.add('alchemy-popup-open');
}

function closeAlchemyPopupV10() {
  document.getElementById('alchemy-popup-v10')?.classList.add('hidden');
  document.body.classList.remove('alchemy-popup-open');
}

function openAlchemyRealmPopupV10(level) {
  const realm = ALCHEMY_REALMS_V10.find(item => item.level === Number(level)) || { level: Number(level), name: `Đan sư cấp ${level}` };
  const recipes = alchemyRecipesV10().filter(recipe => alchemyRecipeLevelV10(recipe) === realm.level);
  const unlocked = alchemyPlayerLevelV10() >= realm.level;
  const html = `
    <header class="alchemy-popup-title">
      <span>Đan Các · ${escapeHtml(realm.name)}</span>
      <h2>Phương Đan ${escapeHtml(realm.name)}</h2>
      <p>${unlocked ? 'Chọn một phương đan để xem chi tiết rồi khai lò.' : 'Cảnh giới Đan Sư hiện tại chưa đủ để luyện nhóm này.'}</p>
    </header>
    <div class="alchemy-popup-recipe-grid">
      ${recipes.length ? recipes.map(recipe => {
        const pill = alchemyRecipePillV10(recipe) || recipe;
        return `<button type="button" class="alchemy-popup-recipe" data-alchemy-recipe-detail="${escapeHtml(recipe.id)}">
          <b>${escapeHtml(recipe.name || pill.name || recipe.id)}</b>
          <span>${escapeHtml(alchemyTimeTextV10(recipe.durationMs || recipe.durationSeconds || recipe.craftTime || recipe.craftTimeMs || 0))} · ${escapeHtml(alchemySuccessTextV10(recipe))}</span>
          <p>${escapeHtml(alchemyEffectTextV10(pill)).slice(0, 150)}</p>
        </button>`;
      }).join('') : '<p class="empty">Cảnh giới này chưa có phương đan.</p>'}
    </div>`;
  openAlchemyPopupV10(html);
  document.querySelectorAll('[data-alchemy-recipe-detail]').forEach(btn => {
    btn.addEventListener('click', () => openAlchemyRecipeDetailV10(btn.dataset.alchemyRecipeDetail));
  });
}

function openAlchemyRecipeDetailV10(recipeId) {
  const recipe = alchemyRecipesV10().find(item => String(item.id) === String(recipeId));
  if (!recipe) return;
  const pill = alchemyRecipePillV10(recipe) || recipe;
  const canCraft = (playerData?.activeTab || currentTab) === 'alchemy' && alchemyPlayerLevelV10() >= alchemyRecipeLevelV10(recipe);
  const html = `
    <header class="alchemy-popup-title">
      <span>Đan Phương</span>
      <h2>${escapeHtml(recipe.name || pill.name || recipe.id)}</h2>
      <p>Thành đan: ${escapeHtml(pill.name || recipe.pillId || 'Chưa rõ')}</p>
    </header>
    <div class="alchemy-detail-grid">
      <section class="wide"><h3>Công hiệu</h3><p>${escapeHtml(alchemyEffectTextV10(pill))}</p></section>
      <section><h3>Đạo hạnh luyện đan</h3>
        <div class="alchemy-stat-line"><span>Thời gian</span><b>${escapeHtml(alchemyTimeTextV10(recipe.durationMs || recipe.durationSeconds || recipe.craftTime || recipe.craftTimeMs || 0))}</b></div>
        <div class="alchemy-stat-line"><span>Tỷ lệ thành công</span><b>${escapeHtml(alchemySuccessTextV10(recipe))}</b></div>
        <div class="alchemy-stat-line"><span>Yêu cầu</span><b>${escapeHtml(alchemyRequirementTextV10(recipe))}</b></div>
      </section>
      <section><h3>Linh tài cần dùng</h3>${alchemyMaterialRowsV10(recipe)}</section>
    </div>
    <div class="alchemy-popup-actions"><button type="button" ${canCraft ? '' : 'disabled'} data-alchemy-craft="${escapeHtml(recipe.id)}">${canCraft ? 'Khai Lò Luyện Đan' : 'Chưa đủ điều kiện luyện'}</button></div>`;
  openAlchemyPopupV10(html);
  document.querySelector('[data-alchemy-craft]')?.addEventListener('click', async event => {
    const id = event.currentTarget.dataset.alchemyCraft;
    closeAlchemyPopupV10();
    try { await craftPill(id); } catch (err) { alert(err.message); }
  });
}

function openAlchemyPillDetailV10(itemId) {
  const item = alchemyInventoryPillsV10().find(pill => String(pill.id) === String(itemId));
  if (!item) return;
  const pill = alchemyFindPillV10(item.basePillId || item.pillId || item.id) || item;
  const html = `
    <header class="alchemy-popup-title">
      <span>Linh Đan</span>
      <h2>${escapeHtml(item.name || pill.name || item.id)}</h2>
      <p>${escapeHtml(item.quality || pill.quality || 'Đan dược')} · Số lượng ${fmt(item.amount || item.count || 1)}</p>
    </header>
    <div class="alchemy-detail-grid">
      <section class="wide"><h3>Công hiệu</h3><p>${escapeHtml(alchemyEffectTextV10(pill))}</p></section>
      <section><h3>Thông tin</h3>
        <div class="alchemy-stat-line"><span>Số lượng</span><b>${fmt(item.amount || item.count || 1)}</b></div>
        <div class="alchemy-stat-line"><span>Hiệu lực</span><b>${escapeHtml(pill.durationMs || pill.durationSeconds ? alchemyTimeTextV10(pill.durationMs || pill.durationSeconds) : 'Dùng ngay')}</b></div>
      </section>
    </div>
    <div class="alchemy-popup-actions"><button type="button" data-alchemy-use-pill="${escapeHtml(item.id)}">Dùng Đan</button></div>`;
  openAlchemyPopupV10(html);
  document.querySelector('[data-alchemy-use-pill]')?.addEventListener('click', async event => {
    const id = event.currentTarget.dataset.alchemyUsePill;
    closeAlchemyPopupV10();
    try { await usePill(id); } catch (err) { alert(err.message); }
  });
}

async function usePill(itemId) {
  const data = await api(`/api/player/${encodeURIComponent(username)}/pill/use`, { method: 'POST', body: JSON.stringify({ itemId }) });
  playerData = data.player;
  renderAll();
}

function renderAlchemy() {
  setText('alchemy-bonus', `+${fmt(playerData?.cave?.alchemyBonus || 0)}%`);
  const recipeBox = $('recipe-list');
  const pillBox = $('pill-list');
  const level = alchemyPlayerLevelV10();
  const recipes = alchemyRecipesV10();

  if (recipeBox) {
    recipeBox.className = 'alchemy-realm-grid-v10';
    recipeBox.innerHTML = ALCHEMY_REALMS_V10.map(realm => {
      const count = recipes.filter(recipe => alchemyRecipeLevelV10(recipe) === realm.level).length;
      const unlocked = level >= realm.level;
      return `
        <button type="button" class="alchemy-realm-card-v10 ${unlocked ? 'unlocked' : 'locked'}" data-alchemy-realm="${realm.level}">
          <div>
            <h3>${escapeHtml(realm.name)}</h3>
            <p>Đan sư cấp ${realm.level} · ${unlocked ? 'đã mở' : 'chưa mở'} ${count}/6 phương đan</p>
          </div>
          <span>${unlocked ? 'Mở' : 'Khóa'}</span>
        </button>`;
    }).join('');
    recipeBox.querySelectorAll('[data-alchemy-realm]').forEach(btn => {
      btn.addEventListener('click', () => openAlchemyRealmPopupV10(btn.dataset.alchemyRealm));
    });
  }

  const pills = alchemyInventoryPillsV10();
  if (pillBox) {
    pillBox.className = 'alchemy-pill-grid-v10';
    pillBox.innerHTML = pills.length ? pills.map(item => {
      const pill = alchemyFindPillV10(item.basePillId || item.pillId || item.id) || item;
      return `
        <button type="button" class="alchemy-pill-card-v10" data-alchemy-pill="${escapeHtml(item.id)}">
          <div>
            <h3>${escapeHtml(item.name || pill.name || item.id)}</h3>
            <p>${escapeHtml(item.quality || pill.quality || 'Đan dược')} · x${fmt(item.amount || item.count || 1)}</p>
          </div>
          <span>Xem</span>
        </button>`;
    }).join('') : '<p class="empty">Chưa có đan dược.</p>';
    pillBox.querySelectorAll('[data-alchemy-pill]').forEach(btn => {
      btn.addEventListener('click', () => openAlchemyPillDetailV10(btn.dataset.alchemyPill));
    });
  }
}

async function craftPill(recipeId) {
  try {
    const data = await api(`/api/player/${encodeURIComponent(username)}/alchemy/craft`, { method: 'POST', body: JSON.stringify({ recipeId }) });
    playerData = data.player;
    renderAll();
  } catch (err) { alert(err.message); }
}

function renderCave() {
  const cave = playerData.cave || {};
  setText('cave-level', `Cấp ${cave.level || 1}`);
  setText('cave-aura', fmt(cave.resources?.aura || 0));
  setText('cave-rate', `${fmt(cave.auraPerSecond || 0)}/s`);
  setText('cave-alchemy', `${fmt(cave.alchemyBonus || 0)}%`);
  $('cave-buildings').innerHTML = '<p class="empty">Kiến trúc động phủ sẽ mở ở bước sau.</p>';
  const plots = playerData.herbPlots || playerData.cave?.herbPlots || [];
  $('herb-plots').innerHTML = plots.length ? plots.map((plot, idx) => `<div class="garden-plot"><b>Ô Dược Viên ${idx + 1}</b><p>${escapeHtml(plot.herbName || plot.name || (plot.herbId ? plot.herbId : 'Ô trống'))}</p></div>`).join('') : '<p class="empty">Dược viên chưa khai mở.</p>';
}

function renderInventory() {
  const inv = playerData.inventory || [];
  const currencies = Object.entries(playerData.currencies || {}).filter(([, amount]) => Number(amount) > 0);
  setText('inventory-count', `${inv.length} vật phẩm · ${currencies.length} tiền tệ`);
  const currencyHtml = currencies.length ? `<h4>Tiền tệ</h4><div class="inventory-grid">${currencies.map(([id, amount]) => smallCard(currencyName(id), `Số lượng: ${fmt(amount)}`, 'Tiền tệ')).join('')}</div>` : '<p class="empty">Chưa có tiền tệ.</p>';
  const itemHtml = inv.length ? `<h4>Vật phẩm</h4><div class="inventory-grid">${inv.map(item => smallCard(item.name || item.id, `Số lượng: ${fmt(item.amount)}`, item.quality || item.type || 'Vật phẩm')).join('')}</div>` : '<p class="empty">Chưa có vật phẩm rơi vào túi.</p>';
  $('inventory-list').innerHTML = currencyHtml + itemHtml;
}

function currencyName(id) {
  return { so_linh_thach: 'Sơ Linh Thạch', trung_linh_thach: 'Trung Linh Thạch', cao_linh_thach: 'Cao Linh Thạch', cuc_pham_linh_thach: 'Cực Phẩm Linh Thạch', tien_ngoc: 'Tiên Ngọc' }[id] || id;
}

window.addEventListener('DOMContentLoaded', async () => {
  bindEvents();
  if (username) {
    const input = $('username-input');
    if (input) input.value = username;
    showApp();
    await loadMeta();
    await loadPlayer();
    setTab(currentTab, true);
    startTimer();
  }
});

