// Đã hợp nhất render Nhật Ký Đạo Hành vào script.js.
