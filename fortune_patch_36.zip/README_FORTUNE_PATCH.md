# Fortune Patch - 36 Kỳ Ngộ Nhân Giới

Bộ patch này tách hệ thống kỳ ngộ thành dữ liệu riêng để sau này dễ thêm kỳ ngộ mới.

## File

```txt
config/fortunes.js
core/fortuneEngine.js
core/fortuneRewards.js
```

## Nội dung hiện tại

- 36 kỳ ngộ Nhân Giới.
- 20 Phàm Duyên.
- 10 Linh Duyên.
- 5 Huyền Duyên.
- 1 Thiên Mệnh.
- Mỗi kỳ ngộ có 3 lựa chọn.
- Mỗi lựa chọn có nhiều kết quả ngẫu nhiên: thưởng, phạt hoặc không có gì.

## Ghi chú tích hợp

Nếu project đã có `core/fortuneEngine.js` và `core/fortuneRewards.js` từ patch trước thì chỉ cần thay `config/fortunes.js`.
Nếu chưa có thì copy cả 3 file vào đúng thư mục.
