const ACTIVITY_CATEGORY_LABELS = {
  item: 'Vật Phẩm',
  alchemy: 'Luyện Đan',
  fortune: 'Kỳ Ngộ',
  garden: 'Dược Viên',
  skill: 'Công Pháp',
  cultivation: 'Tu Luyện',
  system: 'Thiên Cơ',
};

function ensureActivityLog(player) {
  if (!player) return [];
  if (!Array.isArray(player.activityLog)) player.activityLog = [];
  return player.activityLog;
}

function addActivityLog(player, category, text, detail = '') {
  const logs = ensureActivityLog(player);
  const safeCategory = category || 'system';
  logs.unshift({
    id: `${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
    at: Date.now(),
    category: safeCategory,
    categoryLabel: ACTIVITY_CATEGORY_LABELS[safeCategory] || ACTIVITY_CATEGORY_LABELS.system,
    text: String(text || 'Đạo hành biến động'),
    detail: detail ? String(detail) : '',
  });
  while (logs.length > 80) logs.pop();
  return logs[0];
}

function publicActivityLog(player, limit = 40) {
  return ensureActivityLog(player).slice(0, limit);
}

module.exports = {
  ACTIVITY_CATEGORY_LABELS,
  ensureActivityLog,
  addActivityLog,
  publicActivityLog,
};
