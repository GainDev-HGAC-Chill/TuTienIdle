# Fix Nhật Ký Đạo Hành - Luyện Đan & Dùng Đan

## Lỗi đã xử lý

Bản patch trước có thể đã tạo panel log ở Tổng Quan, nhưng chưa ghi log khi:

- Luyện chế đan dược qua `/api/player/:username/alchemy/craft`
- Sử dụng đan dược qua `/api/player/:username/pill/use`
- Sử dụng đan qua endpoint chung `/api/player/:username/use`

Nguyên nhân: mốc patch không khớp với `server.js` hiện tại nên đoạn `addActivityLog(...)` không được gắn vào đúng endpoint.

## Cách dùng

Copy thư mục `core` và `tools` vào repo, sau đó chạy:

```bash
node tools/fix_activity_log_alchemy.js
npm start
```

Sau khi server chạy, mở web và nhấn:

```txt
Ctrl + F5
```

## File được sửa

- `core/activityLog.js`
- `server.js`

Script tự backup file cũ dạng:

```txt
server.js.bak_activity_alchemy_xxx
core/activityLog.js.bak_activity_alchemy_xxx
```

## Kết quả mong muốn

Khi luyện đan thành công, Tổng Quan sẽ hiện log dạng:

```txt
[Luyện Đan] Luyện thành Thọ Nguyên Đan phẩm chất Tốt.
Công thức: recipe_tho_nguyen_dan
```

Khi dùng đan thành công, Tổng Quan sẽ hiện log dạng:

```txt
[Vật Phẩm] Dùng Thọ Nguyên Đan, tăng 30 năm thọ nguyên.
Vật phẩm: tho_nguyen_dan
```

Combat vẫn không ghi vào Nhật Ký Đạo Hành.
