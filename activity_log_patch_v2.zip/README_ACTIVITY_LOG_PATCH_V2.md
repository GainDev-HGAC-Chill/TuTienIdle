# Patch V2 - Nhật Ký Đạo Hành

Bản này sửa lỗi bản trước không thấy log ở Tổng Quan do không tìm thấy mốc trong `index.html/server.js/script.js`.

## Cách dùng

Giải nén đè vào thư mục repo `TuTienIdle`, sau đó chạy:

```bash
node tools/apply_activity_log_patch.js
npm start
```

Sau đó mở lại trình duyệt, nên nhấn `Ctrl + F5`.

## Điểm khác bản cũ

- Không còn phụ thuộc vào mốc HTML của `index.html`.
- `frontend/script.js` sẽ tự tạo panel `Nhật Ký Đạo Hành` trong tab Tổng Quan nếu chưa có.
- `server.js` được patch để trả `player.activityLog` về client.
- Không hook vào combat log, nên đánh quái không hiện trong nhật ký này.

## Log hiện có

- Đổi mạch tu luyện
- Trang bị/tháo công pháp
- Trang bị/tháo vũ kỹ
- Gieo trồng/thu hoạch dược liệu
- Luyện chế/luyện đan
- Sử dụng đan dược/vật phẩm
- Chọn/từ chối kỳ ngộ
