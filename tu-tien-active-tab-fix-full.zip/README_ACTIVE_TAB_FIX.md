# Bản sửa Active Tab + Tháo Công Pháp

Copy đè 4 file:

- `server.js`
- `frontend/index.html`
- `frontend/script.js`
- `frontend/style.css`

## Logic đã sửa

- Đang ở tab **Tu Luyện**: chỉ sinh tu vi/luyện thể/luyện hồn, không đánh quái.
- Đang ở tab **Combat**: chỉ đánh quái, không sinh tu vi nền, không luyện đan.
- Đang ở tab **Đan Dược**: mới được luyện đan.
- Đang ở tab **Động Phủ**: mới tích linh khí, gieo trồng, thu hoạch.
- Tab khác: các hoạt động tự động tạm dừng.
- Nút **Tháo** công pháp/vũ kỹ đã giữ trạng thái tháo, không bị auto trang bị lại khi refresh.

## Chạy test

```bash
node --check server.js
node --check frontend/script.js
npm start
```

Sau đó Ctrl + F5 trên trình duyệt.
