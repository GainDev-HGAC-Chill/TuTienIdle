# UI full copy đè

Copy đè 2 file sau vào project:

- frontend/script.js
- frontend/style.css

Sau đó chạy:

```bash
node --check server.js
npm start
```

Mở trình duyệt và nhấn Ctrl + F5.

Bản này đã gộp sẵn UI Combat + Tu Luyện vào full file script.js, không cần dán snippet xuống cuối file nữa.
