# Bản full sửa UI + thao tác

Copy đè 4 file:

- `server.js`
- `frontend/index.html`
- `frontend/script.js`
- `frontend/style.css`

Sau đó chạy:

```bash
node --check server.js
node --check frontend/script.js
npm start
```

Mở trình duyệt và nhấn `Ctrl + F5`.

Đã sửa:

- Hiện lại Thọ Nguyên ở Tổng Quan.
- Đan dược hiển thị công hiệu + công thức.
- Đan dược trong túi có nút Dùng.
- Công pháp/vũ kỹ có nút Tháo.
- Dược viên có chọn cây, gieo trồng, thu hoạch.
- Thêm route `POST /api/player/:username/technique/unequip` vào server.
